package GUI;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jerry
 */
public class Lecturer {
    
    
    
    public static void main(String[] args) throws IOException {

        
        File f = new File("lecturer.txt");
        
        if(f.createNewFile())
            System.out.println("File " + f.getName() + " was created.");
        else 
            System.out.println("File " + f.getName() + " was not created.");
    }
    private String name;
    private String userid;
    private String password; 
    private String nextline;
    private Boolean login = false;
    
    public  Lecturer() {
        userid = null;
        password = null; 
        
    }
    public Lecturer(String userid) {
        this.userid = userid;
    }
    public Lecturer(String userid, String Password) {
        this.userid = userid;
        this.password= userid;
    }
    public String getID(){
        return userid;
    }
    public String getPassword() {
        return password;

    }
    public void setID(String userid){
        this.userid = userid;
        
    }
    public void setPassword(String password) {
        this.password = password;
    }
    
    private static Scanner Scanner;
    
    public void LecturerLoginVerification(String userid, String password, String file) {
        boolean login = false;
        try {
            Scanner = new Scanner (new File(file));
            while(Scanner.hasNextLine()) {
                String line = Scanner.nextLine();
                String[] split = line.split(" \\; ");
                if (split[0].equals(userid) && split[1].equals(password)) {
                    login = true;
                    LecturerMainMenu mm = new LecturerMainMenu(userid);
                    mm.setVisible(true);
                    
                    break;
                }
            }
            if (login == false) {
                JOptionPane.showMessageDialog(null, "Incorrect ID or password.");
            }
            Scanner.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    
    public void getName(String userid) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("Lecturer.txt"));
            String line = null;
            while((line = br.readLine()) != null) {
                String record[] = line.split(" \\; ");
                if (record[0].equals(userid)) {
                    name = record[2];
                }
            }
            br.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    
}

