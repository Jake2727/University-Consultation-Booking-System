package GUI;


import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jerry
 */


public class Student{
    
    public static void main(String[] args) throws IOException {
        
       
        File f = new File("student.txt");
        
        if(f.createNewFile())
            System.out.println("File " + f.getName() + " was created.");
        else 
            System.out.println("File " + f.getName() + " was not created.");
        
    }
    
    
    private String userid;
    private String password; 
    private String nextline;
    private Boolean login = false;
    
    public Student() {
        userid = null;
        password = null; 
        
    }
   
    public Student(String ID, String Password) {
        this.userid = ID;
        this.password= ID;
    }
    
    public String returnid(){
        return userid;
    }
    public String returnpassword() {
        return password;

    }
      
    private static Scanner Scanner;
    
    public void StudentLoginVerification(String userid, String password, String file) {
        
        boolean login = false;
        try {
            
            Scanner = new Scanner (new File(file));
            while(Scanner.hasNextLine()) {
                String line = Scanner.nextLine();
                String[] split = line.split(" \\; ");
                if (split[0].equals(userid) && split[1].equals(password)) {
                    login = true;
                    StudentMainMenu mm = new StudentMainMenu(userid);
                    mm.setVisible(true);
                    
                }
            }
            if(userid == null){
                JOptionPane.showMessageDialog(null,"Please enter User ID");
            }
            if(password == null){
                JOptionPane.showMessageDialog(null,"Please enter password");
            }
            if (login == false) {
                JOptionPane.showMessageDialog(null, "Incorrect ID or password.");
            }
            Scanner.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    void setID(JTextField usertxt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setPassword(JPasswordField passtxt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean StudentLoginVerification() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

