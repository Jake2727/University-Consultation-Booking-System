
import java.io.File;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jerry
 */
public class BookedConsultation {
    public static void main(String[] args) throws IOException {
        
        File f = new File("BookedConsultation.txt");
        
        if(f.createNewFile())
            System.out.println("File " + f.getName() + " was created.");
        else 
            System.out.println("File " + f.getName() + " was not created.");
    }

}
